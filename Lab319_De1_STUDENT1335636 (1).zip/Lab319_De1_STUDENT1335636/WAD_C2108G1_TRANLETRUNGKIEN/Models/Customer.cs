﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WAD_C2108G1_TRANLETRUNGKIEN.Data.Migrations;

namespace WAD_C2108G1_TRANLETRUNGKIEN.Models
{
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [StringLength(3- 32)]
        public string? Fullname { get; set; }
        [Required]
        public DateTime Birthday { get; set; }
        [Required]
        public string? Address { get; set; }
        [Required]
        [EmailAddress]
        public string? Email { get; set; }
        [Required]
        [StringLength(8-20)]
        //[RegularExpression("^")]
        public string? Username { get; set; }
        [Required]
        [MinLength(8)]
        //[RegularExpression("^[A-Za-z1-9]?")]
        public string? Password { get; set; }
        [Required]
        public string? ConfirmPassword { get; set; }
        [Required]
        [ForeignKey(nameof(Class.ID))]
        public int ClassID { get; set; }
        public virtual Class? Class1 { get; set; }
    }
}
