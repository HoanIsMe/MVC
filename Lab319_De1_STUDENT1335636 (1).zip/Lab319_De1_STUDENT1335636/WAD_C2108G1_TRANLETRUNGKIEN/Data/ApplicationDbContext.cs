﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WAD_C2108G1_TRANLETRUNGKIEN.Models;

namespace WAD_C2108G1_TRANLETRUNGKIEN.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<WAD_C2108G1_TRANLETRUNGKIEN.Models.Customer>? Customer { get; set; }
        public DbSet<WAD_C2108G1_TRANLETRUNGKIEN.Models.Class>? Class { get; set; }
    }
}