﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WAD_C2108G1_TRANLETRUNGKIEN.Data;
using WAD_C2108G1_TRANLETRUNGKIEN.Models;
using X.PagedList;
using X.PagedList.Mvc.Core;

namespace WAD_C2108G1_TRANLETRUNGKIEN.Controllers
{
    public class CustomersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CustomersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            int? b = 1;
            int pageSize = 2;
            var applicationDbContext = _context.Customer.Include(c => c.Class1);
            return View(await applicationDbContext.ToPagedListAsync((int)b, pageSize));
        }
        //[Authorizator]
        [HttpGet]
        public async Task<IActionResult> Index(string? q,string x,int? b=1)
        {
            int pageSize = 2;
            List<Customer> classes = _context.Customer.Include(c => c.Class1).ToList();
            ViewData["sortByName"] = (String.IsNullOrEmpty(q)) ? "d" : "";
            ViewData["sortByAddress"] = (String.IsNullOrEmpty(q)) ? "address" : "";
            ViewData["sortByUserName"] = (String.IsNullOrEmpty(q)) ? "username" : "";
            switch (x)
            {
                case "d":classes.OrderBy(z => z.Fullname).ToList();break;
                case "address": classes.OrderBy(z => z.Address).ToList(); break;
                case "username": classes.OrderBy(z => z.Username).ToList(); break;
                default: classes.OrderBy(z => z.Id).ToList(); break;
            }


            if (!string.IsNullOrEmpty(q))
            {
                HashSet<Customer> classesSet = new HashSet<Customer>();
                ViewData["search"] = q;
                string[] ds = q.Split(" ");
                foreach (string d in ds)
                {
                    classesSet = classes.Where(x => x.Fullname.ToLower().Contains(d.ToLower())).ToHashSet();
                }
                classes = new List<Customer>();
                foreach (Customer c in classesSet)
                {
                    classes.Add(c);
                }
            }
            return _context.Class != null ?
                        View(classes.ToPagedListAsync((int)b, pageSize)) :
                        Problem("Entity set 'ApplicationDbContext.Class'  is null.");
        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Customer == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer
                .Include(c => c.Class1)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            ViewData["ClassID"] = new SelectList(_context.Set<Class>(), "ID", "Name");
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Fullname,Birthday,Address,Email,Username,Password,ConfirmPassword,ClassID")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClassID"] = new SelectList(_context.Set<Class>(), "ID", "Name", customer.ClassID);
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Customer == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            ViewData["ClassID"] = new SelectList(_context.Set<Class>(), "ID", "Name", customer.ClassID);
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Fullname,Birthday,Address,Email,Username,Password,ConfirmPassword,ClassID")] Customer customer)
        {
            if (id != customer.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClassID"] = new SelectList(_context.Set<Class>(), "ID", "Name", customer.ClassID);
            return View(customer);
        }

        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Customer == null)
            {
                return NotFound();
            }

            var customer = await _context.Customer
                .Include(c => c.Class1)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Customer == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Customer'  is null.");
            }
            var customer = await _context.Customer.FindAsync(id);
            if (customer != null)
            {
                _context.Customer.Remove(customer);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
          return (_context.Customer?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
