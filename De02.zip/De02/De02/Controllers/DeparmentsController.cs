﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using De02.Data;
using De02.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using X.PagedList;

namespace De02.Controllers
{
    public class DeparmentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DeparmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Deparments
        [HttpGet]
        public async Task<IActionResult> Index(String? q , int? page , string sortOder)
        {
            int pagenumber = page?? 1;
            int pagesize = 5;

            var deparment = _context.Deparment.ToList();
            if (!String.IsNullOrEmpty(q))
            {
                ViewData["keyword"] = q;
                foreach(var w in q.Split(' '))
                {
                    deparment = deparment.Where(dept => dept.DeptName.ToLower().Contains(w.ToLower())).ToList();
                }
            }
            ViewData["sortByName"] = (String.IsNullOrEmpty(sortOder))? "sortByNameDESC": "" ;
            switch (sortOder)
            {
                case "sortByNameDESC" : deparment = deparment.OrderBy(d => d.DeptName).ToList();
                    break;
                default : deparment = deparment.OrderByDescending(d => d.DeptName).ToList();
                    break;
            }
              return _context.Deparment != null ? 
                          View(deparment.ToPagedList(pagenumber, pagesize)) :
                          Problem("Entity set 'ApplicationDbContext.Deparment'  is null.");
        }

        // GET: Deparments/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Deparment == null)
            {
                return NotFound();
            }

            var deparment = await _context.Deparment
                .FirstOrDefaultAsync(m => m.DeptId == id);
            if (deparment == null)
            {
                return NotFound();
            }

            return View(deparment);
        }

        // GET: Deparments/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Deparments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DeptId,DeptName")] Deparment deparment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(deparment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(deparment);
        }

        // GET: Deparments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Deparment == null)
            {
                return NotFound();
            }

            var deparment = await _context.Deparment.FindAsync(id);
            if (deparment == null)
            {
                return NotFound();
            }
            return View(deparment);
        }

        // POST: Deparments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DeptId,DeptName")] Deparment deparment)
        {
            if (id != deparment.DeptId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(deparment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DeparmentExists(deparment.DeptId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(deparment);
        }

        // GET: Deparments/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Deparment == null)
            {
                return NotFound();
            }

            var deparment = await _context.Deparment
                .FirstOrDefaultAsync(m => m.DeptId == id);
            if (deparment == null)
            {
                return NotFound();
            }

            return View(deparment);
        }

        // POST: Deparments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Deparment == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Deparment'  is null.");
            }
            var deparment = await _context.Deparment.FindAsync(id);
            if (deparment != null)
            {
                _context.Deparment.Remove(deparment);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DeparmentExists(int id)
        {
          return (_context.Deparment?.Any(e => e.DeptId == id)).GetValueOrDefault();
        }
    }
}
