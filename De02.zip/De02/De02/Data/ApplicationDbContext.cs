﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using De02.Models;

namespace De02.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        public DbSet<De02.Models.Deparment>? Deparment { get; set; }
        public DbSet<De02.Models.Employee>? Employee { get; set; }
    }
}