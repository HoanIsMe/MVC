﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace De02.Models
{
    public enum Gender
    {
        Male,Female
    }
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmpID { get; set; }
        [ForeignKey(nameof(Deparment.DeptId))]
        public int DeptID { get; set; }
        public virtual Deparment? DeparmentEntity { get; set; }
        [Required]
        public string EmpName { get; set; }
        [Required]
        public string EmpAddress { get; set; }
        [Required]
        [EmailAddress(ErrorMessage ="not invalid")]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.DateTime)]
        public DateTime? Doj { get; set; } = DateTime.Now;
        [Required]
        public Gender Gender { get; set; }
        [Required]
        [Range (1950, 2000)]
        public int YearOfBirth { get; set; }

        

    }
}
